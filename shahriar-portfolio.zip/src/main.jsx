import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight, Github, Linkedin, Mail, MapPin, Menu, X,
  Download, ExternalLink, Cpu, Code2, CircuitBoard, Zap,
  GraduationCap, BriefcaseBusiness, Award, Send, ChevronDown
} from "lucide-react";
import "./styles.css";

const PROFILE = {
  name: "Shahriar Shadman",
  shortName: "Shadman",
  role: "Electrical & Electronics Engineering Student",
  tagline: "I build, learn & turn engineering ideas into working projects.",
  location: "Bangladesh",
  email: "your.email@example.com",
  github: "https://github.com/",
  linkedin: "https://www.linkedin.com/",
  resume: "/resume.pdf",
  photo: "/profile.jpg",
};

const skills = [
  { name: "Electrical Machines", level: "Learning & Lab", icon: Zap },
  { name: "Circuit Analysis", level: "Strong Foundation", icon: CircuitBoard },
  { name: "C / C++", level: "Programming", icon: Code2 },
  { name: "Digital Electronics", level: "Lab & Design", icon: Cpu },
  { name: "MATLAB", level: "Engineering Tools", icon: Cpu },
  { name: "LaTeX", level: "Technical Reports", icon: Code2 },
];

const projects = [
  {
    title: "Open-Circuit Characteristics of DC Generator",
    category: "Electrical Machines",
    description: "Laboratory study of the generated EMF versus field current of a separately excited DC generator, including experimental analysis and characteristic plotting.",
    tags: ["DC Generator", "EEE Lab", "Graph"],
  },
  {
    title: "Hall Effect Experimental Setup",
    category: "Electronics",
    description: "A clean conceptual laboratory setup for studying Hall voltage and understanding charge-carrier behavior in semiconductor materials.",
    tags: ["Hall Effect", "Semiconductor", "Physics"],
  },
  {
    title: "Digital Electronics Lab",
    category: "Digital Systems",
    description: "Collection of digital logic experiments covering Boolean logic, gates, combinational circuits and practical verification.",
    tags: ["Logic Gates", "Digital", "Lab"],
  },
  {
    title: "Engineering Portfolio",
    category: "Web Development",
    description: "A responsive personal website designed to present engineering projects, technical skills, academic work and future goals.",
    tags: ["React", "CSS", "Vercel"],
  },
];

const education = [
  {
    period: "Present",
    title: "B.Sc. in Electrical & Electronics Engineering",
    place: "University / Institution Name",
    text: "Studying electrical engineering fundamentals, electronics, machines, power systems, programming and laboratory work.",
  },
  {
    period: "Previous",
    title: "Higher Secondary Education",
    place: "College Name",
    text: "Science background with a focus on mathematics, physics and related technical subjects.",
  },
];

const certifications = [
  { title: "Certification Name", issuer: "Issuing Organization", year: "2026" },
  { title: "Technical Course", issuer: "Training Platform", year: "2026" },
  { title: "Engineering Workshop", issuer: "Organization", year: "2025" },
];

function App() {
  const [menu, setMenu] = useState(false);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
  }, [dark]);

  const close = () => setMenu(false);

  return (
    <div className="app">
      <div className="noise" />
      <Header menu={menu} setMenu={setMenu} close={close} dark={dark} setDark={setDark} />

      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Journey />
        <Certifications />
        <Contact />
      </main>

      <Footer />
      <a className="top-button" href="#home" aria-label="Back to top">↑</a>
    </div>
  );
}

function Header({ menu, setMenu, close, dark, setDark }) {
  const links = ["About", "Skills", "Projects", "Journey", "Contact"];
  return (
    <header className="nav-wrap">
      <nav className="nav container">
        <a href="#home" className="brand" onClick={close}>
          <span className="brand-mark">S</span>
          <span>{PROFILE.shortName}<b>.</b></span>
        </a>

        <div className={`nav-links ${menu ? "open" : ""}`}>
          {links.map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} onClick={close}>{item}</a>
          ))}
          <a className="nav-cta" href="#contact" onClick={close}>Let's talk <ArrowUpRight size={16}/></a>
        </div>

        <div className="nav-actions">
          <button className="theme-btn" onClick={() => setDark(!dark)} aria-label="Toggle theme">
            {dark ? "☼" : "☾"}
          </button>
          <button className="menu-btn" onClick={() => setMenu(!menu)} aria-label="Menu">
            {menu ? <X/> : <Menu/>}
          </button>
        </div>
      </nav>
    </header>
  );
}

function Hero() {
  return (
    <section id="home" className="hero container section">
      <div className="hero-copy reveal">
        <div className="eyebrow"><span className="pulse" /> Available for learning, projects & collaboration</div>
        <h1>Engineering ideas.<br /><span>Built with purpose.</span></h1>
        <p className="hero-text">
          I'm <strong>{PROFILE.name}</strong>, an EEE student passionate about electronics,
          electrical machines, programming and building useful things.
        </p>
        <div className="hero-actions">
          <a href="#projects" className="button primary">Explore my work <ArrowUpRight size={18}/></a>
          <a href={PROFILE.resume} className="button secondary"><Download size={17}/> Download CV</a>
        </div>
        <div className="socials">
          <a href={PROFILE.github} target="_blank" rel="noreferrer"><Github size={18}/> GitHub</a>
          <a href={PROFILE.linkedin} target="_blank" rel="noreferrer"><Linkedin size={18}/> LinkedIn</a>
          <a href={`mailto:${PROFILE.email}`}><Mail size={18}/> Email</a>
        </div>
      </div>

      <div className="hero-art reveal">
        <div className="orb orb-one" />
        <div className="orb orb-two" />
        <div className="hero-card">
          <div className="terminal-top"><i/><i/><i/><span>~/portfolio</span></div>
          <div className="terminal-body">
            <p><em>01</em> <b>const</b> engineer = &#123;</p>
            <p className="indent">name: <strong>"Shahriar"</strong>,</p>
            <p className="indent">field: <strong>"EEE"</strong>,</p>
            <p className="indent">curiosity: <strong>true</strong>,</p>
            <p className="indent">building: <strong>"projects"</strong></p>
            <p>&#125;;</p>
            <div className="terminal-cursor">▊</div>
          </div>
        </div>
        <div className="floating-chip chip-one"><Zap size={15}/> Electronics</div>
        <div className="floating-chip chip-two"><Code2 size={15}/> Code</div>
      </div>
    </section>
  );
}

function SectionHeading({ eyebrow, title, text }) {
  return (
    <div className="section-heading reveal">
      <div className="eyebrow">{eyebrow}</div>
      <h2>{title}</h2>
      {text && <p>{text}</p>}
    </div>
  );
}

function About() {
  return (
    <section id="about" className="section container">
      <SectionHeading eyebrow="01 — About me" title={<>Curious mind.<br/><span>Engineering heart.</span></>} />
      <div className="about-grid">
        <div className="about-photo reveal">
          <div className="photo-frame">
            <img src={PROFILE.photo} alt={PROFILE.name} onError={(e) => { e.currentTarget.style.display="none"; }} />
            <div className="photo-placeholder"><span>SS</span><small>YOUR PHOTO</small></div>
          </div>
          <div className="photo-caption"><MapPin size={15}/> {PROFILE.location}</div>
        </div>
        <div className="about-content reveal">
          <p className="large-copy">
            I enjoy understanding how things work — from a rotating electrical machine
            to a logic circuit, and from a mathematical model to a web interface.
          </p>
          <p>
            My academic journey in Electrical & Electronics Engineering has given me
            experience with circuit analysis, electrical machines, electronics,
            measurements and programming. I like turning classroom theory into
            practical experiments and presentable projects.
          </p>
          <div className="stats">
            <div><strong>EEE</strong><span>Engineering</span></div>
            <div><strong>∞</strong><span>Curiosity</span></div>
            <div><strong>100%</strong><span>Learning</span></div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Skills() {
  return (
    <section id="skills" className="section alt">
      <div className="container">
        <SectionHeading eyebrow="02 — Skills" title={<>Tools I use to<br/><span>make things real.</span></>} text="A growing technical toolkit built through coursework, laboratory experiments and personal projects." />
        <div className="skills-grid">
          {skills.map(({name, level, icon: Icon}, i) => (
            <div className="skill-card reveal" key={name} style={{"--delay": `${i * 60}ms`}}>
              <div className="icon-box"><Icon size={21}/></div>
              <div><h3>{name}</h3><p>{level}</p></div>
              <span className="skill-arrow">↗</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Projects() {
  return (
    <section id="projects" className="section container">
      <SectionHeading eyebrow="03 — Selected work" title={<>Things I've<br/><span>worked on.</span></>} text="Academic experiments, engineering work and digital projects. Replace these cards with your own work." />
      <div className="project-grid">
        {projects.map((p, i) => (
          <article className={`project-card reveal project-${i+1}`} key={p.title}>
            <div className="project-visual">
              <span className="project-number">0{i+1}</span>
              <div className="project-icon">{i === 0 ? <Zap/> : i === 1 ? <CircuitBoard/> : i === 2 ? <Cpu/> : <Code2/>}</div>
              <div className="visual-lines" />
            </div>
            <div className="project-body">
              <div className="project-meta">{p.category} <ArrowUpRight size={15}/></div>
              <h3>{p.title}</h3>
              <p>{p.description}</p>
              <div className="tags">{p.tags.map(t => <span key={t}>{t}</span>)}</div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function Journey() {
  return (
    <section id="journey" className="section alt">
      <div className="container">
        <SectionHeading eyebrow="04 — Journey" title={<>Education &amp;<br/><span>experience.</span></>} />
        <div className="journey-grid">
          <div>
            <div className="mini-title"><GraduationCap size={19}/> Education</div>
            <div className="timeline">
              {education.map(item => (
                <div className="timeline-item reveal" key={item.title}>
                  <div className="timeline-dot"/>
                  <span>{item.period}</span>
                  <h3>{item.title}</h3>
                  <h4>{item.place}</h4>
                  <p>{item.text}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="experience-panel reveal">
            <div className="mini-title"><BriefcaseBusiness size={19}/> What I'm focused on</div>
            <div className="focus-list">
              {["Electrical & Electronics", "Embedded & Digital Systems", "Programming & Problem Solving", "Technical Documentation", "Practical Engineering Projects"].map((x, i) => (
                <div key={x}><span>0{i+1}</span><b>{x}</b><ArrowUpRight size={16}/></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Certifications() {
  return (
    <section id="certifications" className="section container">
      <SectionHeading eyebrow="05 — Certifications" title={<>Always learning.<br/><span>Always improving.</span></>} />
      <div className="cert-grid">
        {certifications.map((c, i) => (
          <div className="cert-card reveal" key={c.title}>
            <div className="cert-icon"><Award size={22}/></div>
            <div><span>{c.year}</span><h3>{c.title}</h3><p>{c.issuer}</p></div>
            <ExternalLink size={17}/>
          </div>
        ))}
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="contact-section">
      <div className="container contact-grid">
        <div className="contact-copy reveal">
          <div className="eyebrow">06 — Contact</div>
          <h2>Have an idea?<br/><span>Let's build it.</span></h2>
          <p>Whether it's a project, collaboration, internship opportunity or just a technical conversation, feel free to reach out.</p>
          <a className="email-link" href={`mailto:${PROFILE.email}`}><Mail/> {PROFILE.email} <ArrowUpRight size={17}/></a>
        </div>
        <form className="contact-form reveal" onSubmit={(e) => {e.preventDefault(); alert("Thanks! Connect this form to Formspree, EmailJS or your backend to receive messages.");}}>
          <div className="form-row"><label>Name<input required placeholder="Your name"/></label><label>Email<input required type="email" placeholder="you@example.com"/></label></div>
          <label>Subject<input placeholder="What is this about?"/></label>
          <label>Message<textarea required rows="6" placeholder="Tell me a little about it..." /></label>
          <button className="button primary" type="submit">Send message <Send size={17}/></button>
        </form>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div><a className="brand" href="#home"><span className="brand-mark">S</span><span>{PROFILE.shortName}<b>.</b></span></a><p>Designed & built with curiosity.</p></div>
        <div className="footer-links"><a href="#about">About</a><a href="#projects">Projects</a><a href="#contact">Contact</a></div>
        <div className="footer-social"><a href={PROFILE.github}><Github size={18}/></a><a href={PROFILE.linkedin}><Linkedin size={18}/></a></div>
      </div>
      <div className="copyright">© {new Date().getFullYear()} {PROFILE.name}. All rights reserved.</div>
    </footer>
  );
}

createRoot(document.getElementById("root")).render(<App />);
