CUSTOMIZE THIS WEBSITE

1. Open src/main.jsx.
2. Change the PROFILE object near the top:
   - name
   - role
   - email
   - GitHub
   - LinkedIn
   - resume
   - photo

3. Put your photo at:
   public/profile.jpg

4. Put your CV at:
   public/resume.pdf

5. Replace the example skills, projects, education and certifications.

RUN:
npm install
npm run dev

BUILD:
npm run build

DEPLOY:
Upload the project to GitHub and import the repository into Vercel.
